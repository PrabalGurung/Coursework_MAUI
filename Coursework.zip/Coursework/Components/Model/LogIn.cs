﻿public class LogIn
{
    public static bool log = false;
}
