﻿namespace option
{
	public enum Cash_Outflow
	{
		choose,
		debit,
		spending,
		expenses
	}
}
