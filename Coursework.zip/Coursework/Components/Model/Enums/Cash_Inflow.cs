﻿
namespace option
{
    public enum Cash_Inflow
    {
        choose,
        Credit,
        Gain,
        Budget
    }
}