﻿namespace option
{
	public enum Tags { Yearly, Monthly, Food, Drinks, Clothes, Gadgets, Miscellaneous, Fuel, Rent, EMI, Party }
}

